import '@babel/polyfill';

// Include this seperatly since it's not included in core-js
// ref: https://github.com/zloirock/core-js/issues/117
import '../../../node_modules/url-polyfill/url-polyfill.js';
